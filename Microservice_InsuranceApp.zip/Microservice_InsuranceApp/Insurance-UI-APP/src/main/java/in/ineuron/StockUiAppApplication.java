package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockUiAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockUiAppApplication.class, args);
	}

}
//http://localhost:3333/getTotalCost?companyName=HCL&quantity=2
