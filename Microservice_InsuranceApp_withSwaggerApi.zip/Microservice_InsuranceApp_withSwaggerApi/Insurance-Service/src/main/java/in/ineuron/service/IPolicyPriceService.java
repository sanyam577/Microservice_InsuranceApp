package in.ineuron.service;

public interface IPolicyPriceService {
	public Double findByPolicyName(String policyName);
}
